"use client";

import { Menu, Search, ShoppingBag, UserRound, X } from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { useCart } from "@/components/cart-provider";

type HeaderUser = { id: number; name: string; email: string } | null;

const navigation = [
  ["New in", "/shop"],
  ["Fragrance", "/shop?category=fragrance"],
  ["Studs", "/shop?category=studs"],
  ["Clothing", "/shop?category=clothing"],
  ["Shoes", "/shop?category=shoes"],
  ["Watches", "/shop?category=watches"],
] as const;

export function Header({ user }: { user: HeaderUser }) {
  const { itemCount, hydrated } = useCart();
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    setAccountOpen(false);
    router.push("/");
    router.refresh();
  }

  return (
    <>
      <div className="bg-[#1f2922] px-4 py-2 text-center text-[10px] font-medium uppercase tracking-[0.22em] text-white sm:text-[11px]">
        Complimentary delivery over $150 <span className="mx-2 text-white/35">•</span> 14-day returns
      </div>
      <header className="sticky top-0 z-50 border-b border-[#dedbd2] bg-[#f8f6f0]/95 backdrop-blur-md">
        <div className="mx-auto grid h-[72px] max-w-[1440px] grid-cols-[1fr_auto_1fr] items-center px-5 sm:px-8 lg:h-[82px] lg:px-12">
          <button
            type="button"
            aria-label="Open menu"
            onClick={() => setMenuOpen(true)}
            className="justify-self-start text-[#202721] lg:hidden"
          >
            <Menu size={22} />
          </button>

          <nav className="hidden items-center gap-6 justify-self-start text-[11px] font-medium uppercase tracking-[0.12em] lg:flex xl:gap-8">
            {navigation.slice(0, 3).map(([label, href]) => (
              <Link key={label} href={href} className="nav-link">
                {label}
              </Link>
            ))}
          </nav>

          <Link href="/" className="group text-center" aria-label="Aurelia home">
            <span className="block font-serif text-[27px] leading-none tracking-[0.18em] text-[#1f2922] sm:text-[30px]">AURÉLIA</span>
            <span className="mt-1 hidden text-[8px] uppercase tracking-[0.38em] text-[#8c7350] sm:block">Objects of presence</span>
          </Link>

          <div className="flex items-center justify-end gap-5 justify-self-end text-[#202721] sm:gap-6">
            <nav className="mr-2 hidden items-center gap-6 text-[11px] font-medium uppercase tracking-[0.12em] lg:flex xl:gap-8">
              {navigation.slice(3).map(([label, href]) => (
                <Link key={label} href={href} className="nav-link">
                  {label}
                </Link>
              ))}
            </nav>
            <button type="button" onClick={() => setSearchOpen(true)} aria-label="Search">
              <Search size={19} strokeWidth={1.7} />
            </button>
            <div className="relative hidden sm:block">
              <button type="button" onClick={() => setAccountOpen((open) => !open)} aria-label="Account">
                <UserRound size={19} strokeWidth={1.7} />
              </button>
              {accountOpen && (
                <div className="absolute right-0 top-9 w-56 border border-[#dedbd2] bg-[#fffefa] p-4 text-sm shadow-xl">
                  {user ? (
                    <>
                      <p className="font-medium text-[#1f2922]">Hello, {user.name.split(" ")[0]}</p>
                      <p className="mt-1 truncate text-xs text-[#77736b]">{user.email}</p>
                      <div className="my-3 border-t border-[#e4e0d7]" />
                      <Link href="/account" onClick={() => setAccountOpen(false)} className="block py-1.5 hover:text-[#9a7540]">
                        My orders
                      </Link>
                      <button type="button" onClick={logout} className="block w-full py-1.5 text-left hover:text-[#9a7540]">
                        Sign out
                      </button>
                    </>
                  ) : (
                    <>
                      <p className="font-serif text-xl text-[#1f2922]">Your account</p>
                      <p className="mt-1 text-xs leading-5 text-[#77736b]">Sign in to check out and follow your orders.</p>
                      <Link href="/login" onClick={() => setAccountOpen(false)} className="mt-3 block bg-[#1f2922] px-4 py-2.5 text-center text-xs uppercase tracking-widest text-white">
                        Sign in
                      </Link>
                    </>
                  )}
                </div>
              )}
            </div>
            <Link href="/cart" aria-label={`Shopping bag with ${itemCount} items`} className="relative">
              <ShoppingBag size={20} strokeWidth={1.7} />
              {hydrated && itemCount > 0 && (
                <span className="absolute -right-2.5 -top-2.5 grid size-[18px] place-items-center rounded-full bg-[#a67c45] text-[9px] font-semibold text-white">
                  {itemCount > 9 ? "9+" : itemCount}
                </span>
              )}
            </Link>
          </div>
        </div>
      </header>

      <div className={`fixed inset-0 z-[70] transition ${menuOpen ? "visible" : "invisible"}`}>
        <button aria-label="Close menu backdrop" className={`absolute inset-0 bg-black/30 transition-opacity ${menuOpen ? "opacity-100" : "opacity-0"}`} onClick={() => setMenuOpen(false)} />
        <aside className={`absolute left-0 top-0 h-full w-[86%] max-w-sm bg-[#f8f6f0] p-7 transition-transform duration-300 ${menuOpen ? "translate-x-0" : "-translate-x-full"}`}>
          <div className="flex items-center justify-between border-b border-[#dedbd2] pb-6">
            <span className="font-serif text-2xl tracking-[0.16em]">AURÉLIA</span>
            <button type="button" onClick={() => setMenuOpen(false)} aria-label="Close menu"><X size={22} /></button>
          </div>
          <nav className="mt-8 space-y-1">
            {navigation.map(([label, href]) => (
              <Link
                key={label}
                href={href}
                onClick={() => setMenuOpen(false)}
                className={`block border-b border-[#e5e1d8] py-4 font-serif text-2xl ${pathname === href ? "text-[#9a7540]" : "text-[#202721]"}`}
              >
                {label}
              </Link>
            ))}
          </nav>
          <Link href={user ? "/account" : "/login"} onClick={() => setMenuOpen(false)} className="mt-8 flex items-center gap-3 text-sm uppercase tracking-widest">
            <UserRound size={18} /> {user ? "My account" : "Sign in"}
          </Link>
        </aside>
      </div>

      <div className={`fixed inset-0 z-[75] bg-[#f8f6f0] transition-all duration-300 ${searchOpen ? "visible opacity-100" : "invisible opacity-0"}`}>
        <div className="mx-auto max-w-4xl px-6 pt-8 sm:pt-16">
          <div className="flex items-center justify-between">
            <span className="font-serif text-2xl tracking-[0.16em]">AURÉLIA</span>
            <button type="button" onClick={() => setSearchOpen(false)} aria-label="Close search"><X size={24} /></button>
          </div>
          <form action="/shop" onSubmit={() => setSearchOpen(false)} className="mt-20 border-b border-[#2a302b] sm:mt-28">
            <label htmlFor="site-search" className="text-[11px] uppercase tracking-[0.2em] text-[#827c72]">What are you looking for?</label>
            <div className="flex items-center gap-4">
              <input id="site-search" name="q" autoFocus={searchOpen} placeholder="Search the collection" className="w-full bg-transparent py-5 font-serif text-3xl outline-none placeholder:text-[#aaa49a] sm:text-5xl" />
              <button type="submit" aria-label="Submit search"><Search size={26} /></button>
            </div>
          </form>
          <p className="mt-6 text-sm text-[#77736b]">Try “watch”, “gold studs”, or “cedar”</p>
        </div>
      </div>
    </>
  );
}

"use client";

import { ArrowLeft, Check, CreditCard, LoaderCircle, LockKeyhole, Package } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { useCart } from "@/components/cart-provider";
import { formatPrice } from "@/lib/format";

export function CheckoutView({ user }: { user: { name: string; email: string } }) {
  const { items, subtotalCents, hydrated, clearCart } = useCart();
  const [paymentMethod, setPaymentMethod] = useState<"cash_on_delivery" | "demo_card">("cash_on_delivery");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const router = useRouter();
  const shippingCents = subtotalCents >= 15000 ? 0 : 1200;

  async function placeOrder(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (items.length === 0) return;
    setLoading(true);
    setError("");
    const form = new FormData(event.currentTarget);

    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: items.map((item) => ({
            productId: item.id,
            quantity: item.quantity,
            selectedColor: item.selectedColor,
            selectedSize: item.selectedSize,
          })),
          customer: {
            name: form.get("name"),
            phone: form.get("phone"),
            address: form.get("address"),
            city: form.get("city"),
            postalCode: form.get("postalCode"),
          },
          paymentMethod,
        }),
      });
      const data = (await response.json()) as { message?: string; orderNumber?: string };
      if (response.status === 401) {
        router.push("/login?next=/checkout");
        return;
      }
      if (!response.ok || !data.orderNumber) {
        setError(data.message ?? "Your order could not be placed.");
        return;
      }
      clearCart();
      router.push(`/order-confirmed?order=${encodeURIComponent(data.orderNumber)}`);
      router.refresh();
    } catch {
      setError("We could not connect to checkout. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  if (!hydrated) return <div className="min-h-[600px] animate-pulse bg-[#eee9df]" />;

  if (items.length === 0) {
    return (
      <main className="grid min-h-[65vh] place-items-center px-6 text-center">
        <div><Package size={36} strokeWidth={1.2} className="mx-auto" /><h1 className="mt-5 font-serif text-4xl">There’s nothing to check out.</h1><Link href="/shop" className="button-dark mt-7">Return to shop</Link></div>
      </main>
    );
  }

  return (
    <main className="bg-[#eee9df]">
      <form onSubmit={placeOrder} className="mx-auto grid min-h-[760px] max-w-[1400px] lg:grid-cols-[1.15fr_0.85fr]">
        <section className="bg-[#f8f6f0] px-5 py-12 sm:px-12 lg:px-20 lg:py-16">
          <div className="mx-auto max-w-2xl">
            <Link href="/cart" className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.16em] text-[#6d6e69]"><ArrowLeft size={14} /> Back to bag</Link>
            <p className="eyebrow mt-10 text-[#9a7540]">Secure checkout</p>
            <h1 className="mt-3 font-serif text-5xl tracking-[-0.035em]">Where shall we send it?</h1>
            <p className="mt-4 text-sm text-[#77736b]">Signed in as {user.email}</p>

            <div className="mt-10">
              <h2 className="mb-6 flex items-center gap-3 font-serif text-2xl"><span className="grid size-7 place-items-center rounded-full border border-[#9a7540] text-xs text-[#9a7540]">1</span> Delivery details</h2>
              <div className="grid gap-5 sm:grid-cols-2">
                <div className="sm:col-span-2"><label htmlFor="name" className="form-label">Full name</label><input id="name" name="name" required defaultValue={user.name} autoComplete="name" className="form-input" /></div>
                <div><label htmlFor="phone" className="form-label">Phone</label><input id="phone" name="phone" required autoComplete="tel" className="form-input" placeholder="Your phone number" /></div>
                <div><label htmlFor="postalCode" className="form-label">Postal code</label><input id="postalCode" name="postalCode" required autoComplete="postal-code" className="form-input" placeholder="Postal code" /></div>
                <div className="sm:col-span-2"><label htmlFor="address" className="form-label">Street address</label><input id="address" name="address" required autoComplete="street-address" className="form-input" placeholder="House number and street" /></div>
                <div className="sm:col-span-2"><label htmlFor="city" className="form-label">City</label><input id="city" name="city" required autoComplete="address-level2" className="form-input" placeholder="City" /></div>
              </div>
            </div>

            <div className="mt-12 border-t border-[#dedbd2] pt-10">
              <h2 className="mb-6 flex items-center gap-3 font-serif text-2xl"><span className="grid size-7 place-items-center rounded-full border border-[#9a7540] text-xs text-[#9a7540]">2</span> Payment</h2>
              <div className="grid gap-3 sm:grid-cols-2">
                <button type="button" onClick={() => setPaymentMethod("cash_on_delivery")} className={`flex min-h-20 items-center gap-4 border p-4 text-left ${paymentMethod === "cash_on_delivery" ? "border-[#1f2922] bg-[#f0ebe2]" : "border-[#d5d0c6] bg-[#fffefa]"}`}>
                  <Package size={21} strokeWidth={1.4} /><span><strong className="block text-sm font-medium">Cash on delivery</strong><small className="text-[#77736b]">Pay when it arrives</small></span>{paymentMethod === "cash_on_delivery" && <Check size={16} className="ml-auto" />}
                </button>
                <button type="button" onClick={() => setPaymentMethod("demo_card")} className={`flex min-h-20 items-center gap-4 border p-4 text-left ${paymentMethod === "demo_card" ? "border-[#1f2922] bg-[#f0ebe2]" : "border-[#d5d0c6] bg-[#fffefa]"}`}>
                  <CreditCard size={21} strokeWidth={1.4} /><span><strong className="block text-sm font-medium">Demo card</strong><small className="text-[#77736b]">No real charge</small></span>{paymentMethod === "demo_card" && <Check size={16} className="ml-auto" />}
                </button>
              </div>
              {paymentMethod === "demo_card" && (
                <div className="mt-4 border border-[#d5d0c6] bg-[#fffefa] p-5 text-sm leading-6 text-[#666963]">
                  This portfolio checkout simulates card approval—no card details are requested or processed.
                </div>
              )}
            </div>

            {error && <p role="alert" className="mt-6 border-l-2 border-[#9c4e3e] bg-[#f4e8e3] px-4 py-3 text-sm text-[#784034]">{error}</p>}
            <button type="submit" disabled={loading} className="button-dark mt-8 w-full sm:w-auto">
              {loading ? <><LoaderCircle size={16} className="animate-spin" /> Processing order</> : <><LockKeyhole size={15} /> Place order · {formatPrice(subtotalCents + shippingCents)}</>}
            </button>
          </div>
        </section>

        <aside className="px-5 py-12 sm:px-12 lg:px-16 lg:py-20">
          <div className="mx-auto max-w-lg lg:sticky lg:top-32">
            <h2 className="font-serif text-3xl">Your order</h2>
            <div className="mt-7 max-h-[420px] space-y-5 overflow-auto pr-2">
              {items.map((item) => (
                <div key={item.key} className="grid grid-cols-[76px_1fr_auto] gap-4">
                  <div className="relative aspect-[4/5] bg-[#ddd7cc]"><img src={item.image} alt="" className="h-full w-full object-cover" /><span className="absolute -right-2 -top-2 grid size-5 place-items-center rounded-full bg-[#1f2922] text-[9px] text-white">{item.quantity}</span></div>
                  <div className="min-w-0 py-1"><p className="font-serif text-lg">{item.name}</p><p className="mt-1 text-[11px] text-[#77736b]">{[item.selectedColor, item.selectedSize].filter(Boolean).join(" · ")}</p></div>
                  <p className="py-1 text-xs">{formatPrice(item.priceCents * item.quantity)}</p>
                </div>
              ))}
            </div>
            <dl className="mt-8 space-y-4 border-y border-[#d2cdc4] py-6 text-sm">
              <div className="flex justify-between"><dt className="text-[#6f716c]">Subtotal</dt><dd>{formatPrice(subtotalCents)}</dd></div>
              <div className="flex justify-between"><dt className="text-[#6f716c]">Delivery</dt><dd>{shippingCents === 0 ? "Complimentary" : formatPrice(shippingCents)}</dd></div>
            </dl>
            <div className="flex justify-between py-6"><p>Total <span className="ml-1 text-xs text-[#77736b]">USD</span></p><p className="font-serif text-2xl">{formatPrice(subtotalCents + shippingCents)}</p></div>
            <p className="flex items-center gap-2 text-[10px] uppercase tracking-[0.12em] text-[#77736b]"><LockKeyhole size={13} /> Encrypted and securely stored order</p>
          </div>
        </aside>
      </form>
    </main>
  );
}

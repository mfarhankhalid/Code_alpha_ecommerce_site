"use client";

import type { Product } from "@/db/schema";
import { Heart, Star } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { QuickAddButton } from "@/components/add-to-cart";
import { formatPrice } from "@/lib/format";

export function ProductCard({ product, priority = false }: { product: Product; priority?: boolean }) {
  const [saved, setSaved] = useState(false);
  const cartProduct = {
    id: product.id,
    slug: product.slug,
    name: product.name,
    tagline: product.tagline,
    image: product.image,
    imageAlt: product.imageAlt,
    priceCents: product.priceCents,
    stock: product.stock,
  };

  return (
    <article className="product-card group min-w-0">
      <div className="product-image-wrap aspect-[4/5]">
        <Link href={`/product/${product.slug}`} aria-label={`View ${product.name}`}>
          <img src={product.image} alt={product.imageAlt} loading={priority ? "eager" : "lazy"} className="h-full w-full object-cover" />
        </Link>
        {product.badge && (
          <span className="absolute left-3 top-3 bg-[#f8f6f0] px-3 py-1.5 text-[9px] font-semibold uppercase tracking-[0.16em] text-[#333a34]">
            {product.badge}
          </span>
        )}
        <button
          type="button"
          onClick={() => setSaved((value) => !value)}
          aria-label={saved ? "Remove from wishlist" : "Save to wishlist"}
          aria-pressed={saved}
          className="absolute right-3 top-3 grid size-9 place-items-center rounded-full bg-[#fffefa]/85 text-[#1f2922] backdrop-blur-sm"
        >
          <Heart size={16} fill={saved ? "currentColor" : "none"} />
        </button>
        <QuickAddButton product={cartProduct} defaultColor={product.colors[0]} defaultSize={product.sizes[0]} />
      </div>
      <div className="pt-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <Link href={`/product/${product.slug}`} className="font-serif text-[19px] leading-tight text-[#202721] hover:text-[#9a7540]">
              {product.name}
            </Link>
            <p className="mt-1 truncate text-xs text-[#7b776f]">{product.tagline}</p>
          </div>
          <div className="shrink-0 text-right text-sm">
            <span>{formatPrice(product.priceCents)}</span>
            {product.compareAtCents && <span className="ml-2 text-xs text-[#98938a] line-through">{formatPrice(product.compareAtCents)}</span>}
          </div>
        </div>
        <div className="mt-3 flex items-center gap-1 text-[#a67c45]">
          <Star size={11} fill="currentColor" />
          <span className="text-[10px] font-medium text-[#5d5d57]">{(product.rating / 10).toFixed(1)} ({product.reviewCount})</span>
        </div>
      </div>
    </article>
  );
}

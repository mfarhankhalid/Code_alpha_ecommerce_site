"use client";

import { Minus, Plus, ShoppingBag } from "lucide-react";
import { useState } from "react";
import { type CartProduct, useCart } from "@/components/cart-provider";

export function QuickAddButton({ product, defaultColor, defaultSize }: { product: CartProduct; defaultColor?: string; defaultSize?: string }) {
  const { addItem } = useCart();
  return (
    <button
      type="button"
      onClick={() => addItem(product, { color: defaultColor, size: defaultSize })}
      disabled={product.stock < 1}
      className="quick-add absolute inset-x-3 bottom-3 flex h-11 items-center justify-center gap-2 bg-[#fffefa]/95 text-[10px] font-semibold uppercase tracking-[0.16em] text-[#1f2922] shadow-sm backdrop-blur-sm hover:bg-white disabled:opacity-60"
    >
      <ShoppingBag size={15} strokeWidth={1.8} /> {product.stock > 0 ? "Quick add" : "Sold out"}
    </button>
  );
}

export function ProductPurchase({
  product,
  colors,
  sizes,
}: {
  product: CartProduct;
  colors: string[];
  sizes: string[];
}) {
  const { addItem } = useCart();
  const [color, setColor] = useState(colors[0] ?? "");
  const [size, setSize] = useState(sizes[0] ?? "");
  const [quantity, setQuantity] = useState(1);

  return (
    <div className="mt-8 border-t border-[#ddd8ce] pt-7">
      {colors.length > 0 && (
        <fieldset>
          <div className="mb-3 flex items-center justify-between">
            <legend className="text-[10px] font-semibold uppercase tracking-[0.17em]">{sizes.length ? "Color" : "Choose size"}</legend>
            <span className="text-xs text-[#77736b]">{color}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {colors.map((option) => (
              <button
                key={option}
                type="button"
                aria-pressed={color === option}
                onClick={() => setColor(option)}
                className={`min-w-20 border px-4 py-3 text-xs ${color === option ? "border-[#1f2922] bg-[#1f2922] text-white" : "border-[#d8d3ca] bg-[#fffefa] hover:border-[#807a70]"}`}
              >
                {option}
              </button>
            ))}
          </div>
        </fieldset>
      )}

      {sizes.length > 0 && (
        <fieldset className="mt-6">
          <div className="mb-3 flex items-center justify-between">
            <legend className="text-[10px] font-semibold uppercase tracking-[0.17em]">Size</legend>
            <button type="button" className="text-xs underline underline-offset-4 text-[#77736b]">Size guide</button>
          </div>
          <div className="flex flex-wrap gap-2">
            {sizes.map((option) => (
              <button
                key={option}
                type="button"
                aria-pressed={size === option}
                onClick={() => setSize(option)}
                className={`min-w-12 border px-4 py-3 text-xs ${size === option ? "border-[#1f2922] bg-[#1f2922] text-white" : "border-[#d8d3ca] bg-[#fffefa] hover:border-[#807a70]"}`}
              >
                {option}
              </button>
            ))}
          </div>
        </fieldset>
      )}

      <div className="mt-7 flex gap-3">
        <div className="flex h-[52px] w-32 items-center justify-between border border-[#cfcac1] bg-[#fffefa] px-3">
          <button type="button" onClick={() => setQuantity((value) => Math.max(1, value - 1))} aria-label="Decrease quantity"><Minus size={15} /></button>
          <span className="text-sm">{quantity}</span>
          <button type="button" onClick={() => setQuantity((value) => Math.min(value + 1, 10, product.stock))} aria-label="Increase quantity"><Plus size={15} /></button>
        </div>
        <button
          type="button"
          disabled={product.stock < 1}
          onClick={() => addItem(product, { color, size, quantity })}
          className="button-dark flex-1"
        >
          <ShoppingBag size={16} /> {product.stock > 0 ? "Add to bag" : "Sold out"}
        </button>
      </div>
      <p className="mt-3 text-xs text-[#77736b]">
        {product.stock > 10 ? "In stock · Ready to dispatch" : `Low stock · Only ${product.stock} remaining`}
      </p>
    </div>
  );
}

import { ArrowRight, Camera } from "lucide-react";
import Link from "next/link";

export function Footer() {
  return (
    <footer className="bg-[#1f2922] text-[#f5f0e7]">
      <div className="mx-auto grid max-w-[1440px] gap-12 border-b border-white/15 px-6 py-16 sm:px-10 lg:grid-cols-[1.5fr_1fr_1fr_1fr] lg:px-14 lg:py-20">
        <div className="max-w-sm">
          <p className="font-serif text-3xl tracking-[0.16em]">AURÉLIA</p>
          <p className="mt-5 text-sm leading-6 text-white/60">Beautiful things for everyday rituals. Chosen slowly, made thoughtfully, and designed to remain.</p>
          <form className="mt-8 flex border-b border-white/40" action="#">
            <input type="email" aria-label="Email for newsletter" placeholder="Email address" className="min-w-0 flex-1 bg-transparent py-3 text-sm outline-none placeholder:text-white/40" />
            <button type="submit" aria-label="Join newsletter" className="px-2"><ArrowRight size={18} /></button>
          </form>
          <p className="mt-3 text-[10px] uppercase tracking-[0.15em] text-white/35">A quiet letter, once or twice a month.</p>
        </div>
        <div>
          <p className="footer-title">Shop</p>
          <div className="footer-links">
            <Link href="/shop">New arrivals</Link>
            <Link href="/shop?category=fragrance">Fragrance</Link>
            <Link href="/shop?category=studs">Jewelry</Link>
            <Link href="/shop?category=clothing">Clothing</Link>
          </div>
        </div>
        <div>
          <p className="footer-title">Care</p>
          <div className="footer-links">
            <Link href="/account">Track an order</Link>
            <Link href="/cart">Delivery & returns</Link>
            <a href="mailto:hello@aurelia.store">Contact us</a>
            <span>Care guides</span>
          </div>
        </div>
        <div>
          <p className="footer-title">Visit</p>
          <p className="text-sm leading-7 text-white/55">Monday—Saturday<br />10:00—18:00<br />hello@aurelia.store</p>
          <a href="https://instagram.com" aria-label="Instagram" className="mt-6 inline-block text-white/70 hover:text-white"><Camera size={19} /></a>
        </div>
      </div>
      <div className="mx-auto flex max-w-[1440px] flex-col gap-3 px-6 py-6 text-[10px] uppercase tracking-[0.14em] text-white/35 sm:flex-row sm:items-center sm:justify-between sm:px-10 lg:px-14">
        <p>© 2026 Aurélia. Internship portfolio project.</p>
        <p>Privacy · Terms · Accessibility</p>
      </div>
    </footer>
  );
}

"use client";

import { ArrowRight, Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import Link from "next/link";
import { useCart } from "@/components/cart-provider";
import { formatPrice } from "@/lib/format";

export function CartView() {
  const { items, hydrated, subtotalCents, updateQuantity, removeItem } = useCart();
  const shippingCents = subtotalCents >= 15000 ? 0 : 1200;
  const remaining = Math.max(0, 15000 - subtotalCents);
  const progress = Math.min(100, (subtotalCents / 15000) * 100);

  if (!hydrated) {
    return <div className="mx-auto min-h-[600px] max-w-[1300px] animate-pulse px-6 py-20"><div className="h-12 w-60 bg-[#e5e0d7]" /><div className="mt-12 h-64 bg-[#e5e0d7]" /></div>;
  }

  if (items.length === 0) {
    return (
      <main className="grid min-h-[68vh] place-items-center px-6 py-24 text-center">
        <div>
          <ShoppingBag size={37} strokeWidth={1.2} className="mx-auto text-[#9a7540]" />
          <h1 className="mt-7 font-serif text-5xl tracking-[-0.035em]">Your bag is waiting.</h1>
          <p className="mx-auto mt-4 max-w-md text-sm leading-6 text-[#77736b]">Add something considered to begin your collection.</p>
          <Link href="/shop" className="button-dark mt-8">Explore the collection <ArrowRight size={15} /></Link>
        </div>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-[1300px] px-5 py-14 sm:px-10 lg:px-14 lg:py-20">
      <div className="mb-10 flex items-end justify-between border-b border-[#dedbd2] pb-7">
        <div><p className="eyebrow text-[#9a7540]">Your selection</p><h1 className="mt-2 font-serif text-5xl tracking-[-0.035em]">Shopping bag</h1></div>
        <p className="text-xs text-[#77736b]">{items.reduce((sum, item) => sum + item.quantity, 0)} items</p>
      </div>

      <div className="grid gap-12 lg:grid-cols-[minmax(0,1.5fr)_minmax(320px,0.7fr)] lg:gap-16">
        <section aria-label="Cart items" className="divide-y divide-[#dedbd2]">
          {items.map((item) => (
            <article key={item.key} className="grid grid-cols-[110px_1fr] gap-5 py-6 first:pt-0 sm:grid-cols-[150px_1fr_auto] sm:gap-7">
              <Link href={`/product/${item.slug}`} className="product-image-wrap aspect-[4/5]">
                <img src={item.image} alt={item.imageAlt} className="h-full w-full object-cover" />
              </Link>
              <div className="flex min-w-0 flex-col py-1">
                <div>
                  <p className="text-[9px] font-semibold uppercase tracking-[0.17em] text-[#9a7540]">Aurélia selection</p>
                  <Link href={`/product/${item.slug}`} className="mt-2 block font-serif text-2xl hover:text-[#9a7540]">{item.name}</Link>
                  <p className="mt-1 text-xs text-[#77736b]">{item.tagline}</p>
                  {(item.selectedColor || item.selectedSize) && (
                    <p className="mt-3 text-xs text-[#5d605b]">{[item.selectedColor, item.selectedSize].filter(Boolean).join(" · ")}</p>
                  )}
                </div>
                <div className="mt-auto flex items-center gap-5 pt-5">
                  <div className="flex h-10 w-28 items-center justify-between border border-[#d2cdc3] px-3">
                    <button type="button" onClick={() => updateQuantity(item.key, item.quantity - 1)} aria-label={`Decrease ${item.name} quantity`}><Minus size={13} /></button>
                    <span className="text-xs">{item.quantity}</span>
                    <button type="button" onClick={() => updateQuantity(item.key, item.quantity + 1)} aria-label={`Increase ${item.name} quantity`}><Plus size={13} /></button>
                  </div>
                  <button type="button" onClick={() => removeItem(item.key)} className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.12em] text-[#77736b] hover:text-[#8f4538]"><Trash2 size={13} /> Remove</button>
                </div>
              </div>
              <p className="col-start-2 row-start-1 justify-self-end text-sm sm:col-start-3">{formatPrice(item.priceCents * item.quantity)}</p>
            </article>
          ))}
        </section>

        <aside>
          <div className="border border-[#d7d2c8] bg-[#f1ede5] p-6 sm:p-8 lg:sticky lg:top-32">
            <h2 className="font-serif text-3xl">Order summary</h2>
            <div className="mt-6 bg-[#e5dfd3] p-4">
              <p className="text-xs leading-5 text-[#5f625d]">{remaining > 0 ? <>You’re <strong>{formatPrice(remaining)}</strong> away from complimentary delivery.</> : <strong>Complimentary delivery is yours.</strong>}</p>
              <div className="mt-3 h-1 bg-[#cbc4b8]"><div className="h-full bg-[#9a7540] transition-all" style={{ width: `${progress}%` }} /></div>
            </div>
            <dl className="mt-7 space-y-4 border-b border-[#d3cec4] pb-6 text-sm">
              <div className="flex justify-between"><dt className="text-[#6f716c]">Subtotal</dt><dd>{formatPrice(subtotalCents)}</dd></div>
              <div className="flex justify-between"><dt className="text-[#6f716c]">Delivery</dt><dd>{shippingCents === 0 ? "Complimentary" : formatPrice(shippingCents)}</dd></div>
              <div className="flex justify-between"><dt className="text-[#6f716c]">Taxes</dt><dd>Included</dd></div>
            </dl>
            <div className="flex items-end justify-between py-6"><p className="font-medium">Total</p><p className="font-serif text-2xl">{formatPrice(subtotalCents + shippingCents)}</p></div>
            <Link href="/checkout" className="button-dark w-full">Continue to checkout <ArrowRight size={15} /></Link>
            <p className="mt-4 text-center text-[10px] leading-5 uppercase tracking-[0.12em] text-[#858078]">Secure checkout · 14-day returns</p>
          </div>
        </aside>
      </div>
    </main>
  );
}

"use client";

import { Check, X } from "lucide-react";
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type CartProduct = {
  id: number;
  slug: string;
  name: string;
  tagline: string;
  image: string;
  imageAlt: string;
  priceCents: number;
  stock: number;
};

export type CartItem = CartProduct & {
  key: string;
  quantity: number;
  selectedColor?: string;
  selectedSize?: string;
};

type CartContextValue = {
  items: CartItem[];
  itemCount: number;
  subtotalCents: number;
  hydrated: boolean;
  addItem: (product: CartProduct, options?: { color?: string; size?: string; quantity?: number }) => void;
  updateQuantity: (key: string, quantity: number) => void;
  removeItem: (key: string) => void;
  clearCart: () => void;
};

const CartContext = createContext<CartContextValue | null>(null);
const STORAGE_KEY = "aurelia-cart-v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored) setItems(JSON.parse(stored) as CartItem[]);
    } catch {
      window.localStorage.removeItem(STORAGE_KEY);
    } finally {
      setHydrated(true);
    }
  }, []);

  useEffect(() => {
    if (hydrated) window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }, [items, hydrated]);

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(""), 2600);
    return () => window.clearTimeout(timer);
  }, [notice]);

  function addItem(
    product: CartProduct,
    options: { color?: string; size?: string; quantity?: number } = {},
  ) {
    const quantity = Math.max(1, Math.min(options.quantity ?? 1, 10, product.stock));
    const key = `${product.id}:${options.color ?? ""}:${options.size ?? ""}`;
    setItems((current) => {
      const existing = current.find((item) => item.key === key);
      if (existing) {
        return current.map((item) =>
          item.key === key
            ? { ...item, quantity: Math.min(item.quantity + quantity, 10, item.stock) }
            : item,
        );
      }
      return [
        ...current,
        {
          ...product,
          key,
          quantity,
          selectedColor: options.color,
          selectedSize: options.size,
        },
      ];
    });
    setNotice(`${product.name} added to your bag`);
  }

  function updateQuantity(key: string, quantity: number) {
    setItems((current) =>
      current.map((item) =>
        item.key === key
          ? { ...item, quantity: Math.max(1, Math.min(quantity, 10, item.stock)) }
          : item,
      ),
    );
  }

  function removeItem(key: string) {
    setItems((current) => current.filter((item) => item.key !== key));
  }

  function clearCart() {
    setItems([]);
  }

  const value = useMemo(
    () => ({
      items,
      hydrated,
      itemCount: items.reduce((sum, item) => sum + item.quantity, 0),
      subtotalCents: items.reduce((sum, item) => sum + item.priceCents * item.quantity, 0),
      addItem,
      updateQuantity,
      removeItem,
      clearCart,
    }),
    [items, hydrated],
  );

  return (
    <CartContext.Provider value={value}>
      {children}
      <div
        role="status"
        aria-live="polite"
        className={`fixed bottom-5 left-1/2 z-[80] flex -translate-x-1/2 items-center gap-3 bg-[#1d2520] px-5 py-3 text-sm text-white shadow-2xl transition-all duration-300 ${
          notice ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"
        }`}
      >
        <span className="grid size-6 place-items-center rounded-full bg-[#c6a66a] text-[#1d2520]">
          <Check size={14} strokeWidth={2.5} />
        </span>
        {notice}
        <button type="button" onClick={() => setNotice("")} aria-label="Dismiss notification" className="ml-2 text-white/60 hover:text-white">
          <X size={15} />
        </button>
      </div>
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart must be used within CartProvider");
  return context;
}

"use client";

import { Eye, EyeOff, LoaderCircle } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

export function AuthForm({ mode, nextPath = "/account" }: { mode: "login" | "register"; nextPath?: string }) {
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const isLogin = mode === "login";

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setLoading(true);
    const form = new FormData(event.currentTarget);
    const payload = isLogin
      ? { email: form.get("email"), password: form.get("password") }
      : { name: form.get("name"), email: form.get("email"), password: form.get("password") };

    try {
      const response = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json()) as { message?: string };
      if (!response.ok) {
        setError(data.message ?? "Something went wrong. Please try again.");
        return;
      }
      router.push(nextPath.startsWith("/") ? nextPath : "/account");
      router.refresh();
    } catch {
      setError("We could not connect. Please check your connection and try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className="mt-8 space-y-5">
      {!isLogin && (
        <div>
          <label htmlFor="name" className="form-label">Full name</label>
          <input id="name" name="name" type="text" autoComplete="name" minLength={2} required className="form-input" placeholder="Your name" />
        </div>
      )}
      <div>
        <label htmlFor="email" className="form-label">Email address</label>
        <input id="email" name="email" type="email" autoComplete="email" required className="form-input" placeholder="you@example.com" />
      </div>
      <div>
        <div className="flex items-center justify-between">
          <label htmlFor="password" className="form-label">Password</label>
          {isLogin && <span className="mb-2 text-[11px] text-[#8a744f]">Forgot password?</span>}
        </div>
        <div className="relative">
          <input id="password" name="password" type={showPassword ? "text" : "password"} autoComplete={isLogin ? "current-password" : "new-password"} minLength={8} required className="form-input pr-12" placeholder={isLogin ? "Your password" : "At least 8 characters"} />
          <button type="button" onClick={() => setShowPassword((value) => !value)} className="absolute right-4 top-1/2 -translate-y-1/2 text-[#77736b]" aria-label={showPassword ? "Hide password" : "Show password"}>
            {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
          </button>
        </div>
      </div>
      {error && <p role="alert" className="border-l-2 border-[#9c4e3e] bg-[#f4e8e3] px-4 py-3 text-sm text-[#784034]">{error}</p>}
      <button type="submit" disabled={loading} className="button-dark w-full">
        {loading ? <><LoaderCircle size={16} className="animate-spin" /> Please wait</> : isLogin ? "Sign in" : "Create account"}
      </button>
      <p className="text-center text-sm text-[#77736b]">
        {isLogin ? "New to Aurélia?" : "Already have an account?"}{" "}
        <Link href={isLogin ? `/register?next=${encodeURIComponent(nextPath)}` : `/login?next=${encodeURIComponent(nextPath)}`} className="font-medium text-[#1f2922] underline underline-offset-4">
          {isLogin ? "Create an account" : "Sign in"}
        </Link>
      </p>
    </form>
  );
}

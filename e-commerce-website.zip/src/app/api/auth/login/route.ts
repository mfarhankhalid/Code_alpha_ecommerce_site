import { compare } from "bcryptjs";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { email?: string; password?: string };
    const email = body.email?.trim().toLowerCase();
    const password = body.password ?? "";

    if (!email || !password) {
      return Response.json({ message: "Email and password are required." }, { status: 400 });
    }

    const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (!user || !(await compare(password, user.passwordHash))) {
      return Response.json({ message: "Incorrect email or password." }, { status: 401 });
    }

    await createSession(user.id);
    return Response.json({ ok: true });
  } catch {
    return Response.json({ message: "We could not sign you in. Please try again." }, { status: 500 });
  }
}

import { hash } from "bcryptjs";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { name?: string; email?: string; password?: string };
    const name = body.name?.trim();
    const email = body.email?.trim().toLowerCase();
    const password = body.password ?? "";

    if (!name || name.length < 2) {
      return Response.json({ message: "Please enter your full name." }, { status: 400 });
    }
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      return Response.json({ message: "Please enter a valid email address." }, { status: 400 });
    }
    if (password.length < 8) {
      return Response.json({ message: "Password must be at least 8 characters." }, { status: 400 });
    }

    const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing) {
      return Response.json({ message: "An account with this email already exists." }, { status: 409 });
    }

    const passwordHash = await hash(password, 10);
    const [user] = await db.insert(users).values({ name, email, passwordHash }).returning({ id: users.id });
    await createSession(user.id);

    return Response.json({ ok: true }, { status: 201 });
  } catch {
    return Response.json({ message: "We could not create your account. Please try again." }, { status: 500 });
  }
}

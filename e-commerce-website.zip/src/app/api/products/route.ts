import { getProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const products = await getProducts();
    return Response.json({ products });
  } catch {
    return Response.json({ message: "The product catalog could not be loaded." }, { status: 500 });
  }
}

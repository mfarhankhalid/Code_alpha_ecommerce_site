import { randomBytes } from "crypto";
import { db } from "@/db";
import { orderItems, orders, products } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { ensureCatalog } from "@/lib/catalog";
import { and, desc, eq, gte, inArray, sql } from "drizzle-orm";

type CheckoutItem = {
  productId?: number;
  quantity?: number;
  selectedColor?: string;
  selectedSize?: string;
};

type CheckoutBody = {
  items?: CheckoutItem[];
  customer?: {
    name?: string;
    phone?: string;
    address?: string;
    city?: string;
    postalCode?: string;
  };
  paymentMethod?: string;
};

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return Response.json({ message: "Please sign in before placing your order." }, { status: 401 });
    }

    await ensureCatalog();
    const body = (await request.json()) as CheckoutBody;
    const requestedItems = (body.items ?? []).filter(
      (item): item is CheckoutItem & { productId: number; quantity: number } =>
        Number.isInteger(item.productId) &&
        Number.isInteger(item.quantity) &&
        Number(item.quantity) > 0 &&
        Number(item.quantity) <= 10,
    );

    if (requestedItems.length === 0 || requestedItems.length !== body.items?.length) {
      return Response.json({ message: "Your cart contains an invalid item." }, { status: 400 });
    }

    const customer = body.customer;
    if (
      !customer?.name?.trim() ||
      !customer.phone?.trim() ||
      !customer.address?.trim() ||
      !customer.city?.trim() ||
      !customer.postalCode?.trim()
    ) {
      return Response.json({ message: "Please complete every delivery field." }, { status: 400 });
    }

    const productIds = [...new Set(requestedItems.map((item) => item.productId))];
    const catalogItems = await db.select().from(products).where(inArray(products.id, productIds));
    const catalogMap = new Map(catalogItems.map((product) => [product.id, product]));

    let subtotalCents = 0;
    for (const item of requestedItems) {
      const product = catalogMap.get(item.productId);
      if (!product) {
        return Response.json({ message: "One of your products is no longer available." }, { status: 400 });
      }
      if (product.stock < item.quantity) {
        return Response.json({ message: `Only ${product.stock} ${product.name} left in stock.` }, { status: 409 });
      }
      subtotalCents += product.priceCents * item.quantity;
    }

    const shippingCents = subtotalCents >= 15000 ? 0 : 1200;
    const totalCents = subtotalCents + shippingCents;
    const orderNumber = `AUR-${Date.now().toString().slice(-8)}-${randomBytes(2).toString("hex").toUpperCase()}`;
    const paymentMethod = body.paymentMethod === "demo_card" ? "demo_card" : "cash_on_delivery";

    const order = await db.transaction(async (tx) => {
      const [created] = await tx
        .insert(orders)
        .values({
          orderNumber,
          userId: user.id,
          status: "confirmed",
          subtotalCents,
          shippingCents,
          totalCents,
          customerName: customer.name!.trim(),
          phone: customer.phone!.trim(),
          address: customer.address!.trim(),
          city: customer.city!.trim(),
          postalCode: customer.postalCode!.trim(),
          paymentMethod,
        })
        .returning();

      await tx.insert(orderItems).values(
        requestedItems.map((item) => {
          const product = catalogMap.get(item.productId)!;
          return {
            orderId: created.id,
            productId: product.id,
            productName: product.name,
            productImage: product.image,
            unitPriceCents: product.priceCents,
            quantity: item.quantity,
            selectedColor: item.selectedColor?.slice(0, 60) || null,
            selectedSize: item.selectedSize?.slice(0, 40) || null,
          };
        }),
      );

      for (const item of requestedItems) {
        const updated = await tx
          .update(products)
          .set({ stock: sql`${products.stock} - ${item.quantity}` })
          .where(and(eq(products.id, item.productId), gte(products.stock, item.quantity)))
          .returning({ id: products.id });
        if (updated.length === 0) throw new Error("Inventory changed during checkout");
      }

      return created;
    });

    return Response.json({ ok: true, orderNumber: order.orderNumber }, { status: 201 });
  } catch {
    return Response.json({ message: "Your order could not be placed. Please try again." }, { status: 500 });
  }
}

export async function GET() {
  const user = await getCurrentUser();
  if (!user) {
    return Response.json({ message: "Please sign in." }, { status: 401 });
  }

  const userOrders = await db
    .select()
    .from(orders)
    .where(eq(orders.userId, user.id))
    .orderBy(desc(orders.createdAt));

  if (userOrders.length === 0) return Response.json({ orders: [] });

  const items = await db
    .select()
    .from(orderItems)
    .where(inArray(orderItems.orderId, userOrders.map((order) => order.id)));

  return Response.json({
    orders: userOrders.map((order) => ({
      ...order,
      items: items.filter((item) => item.orderId === order.id),
    })),
  });
}

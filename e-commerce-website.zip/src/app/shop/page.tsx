import type { Metadata } from "next";
import { ChevronDown, Search, SlidersHorizontal } from "lucide-react";
import Link from "next/link";
import { ProductCard } from "@/components/product-card";
import { categories, getProducts } from "@/lib/catalog";

export const metadata: Metadata = { title: "Shop the Collection" };
export const dynamic = "force-dynamic";

type ShopSearchParams = Promise<{ category?: string; q?: string; sort?: string }>;

export default async function ShopPage({ searchParams }: { searchParams: ShopSearchParams }) {
  const params = await searchParams;
  const category = params.category?.toLowerCase() ?? "";
  const query = params.q?.trim().toLowerCase() ?? "";
  const sort = params.sort ?? "featured";
  const allProducts = await getProducts();

  let filtered = allProducts.filter((product) => {
    const matchesCategory = !category || product.category === category;
    const haystack = `${product.name} ${product.tagline} ${product.description} ${product.category}`.toLowerCase();
    return matchesCategory && (!query || haystack.includes(query));
  });

  filtered = [...filtered].sort((a, b) => {
    if (sort === "price-low") return a.priceCents - b.priceCents;
    if (sort === "price-high") return b.priceCents - a.priceCents;
    if (sort === "rating") return b.rating - a.rating;
    return Number(b.featured) - Number(a.featured) || b.id - a.id;
  });

  const activeCategory = categories.find((item) => item.slug === category);

  return (
    <main className="min-h-[70vh]">
      <section className="border-b border-[#dcd7cd] bg-[#eee8de] px-6 py-16 text-center sm:py-20">
        <p className="eyebrow text-[#9a7540]">The full collection</p>
        <h1 className="mt-4 font-serif text-[clamp(3rem,6vw,5.5rem)] leading-none tracking-[-0.04em]">
          {query ? `Results for “${params.q}”` : activeCategory?.name ?? "Considered essentials"}
        </h1>
        <p className="mx-auto mt-5 max-w-xl text-sm leading-6 text-[#6f706a]">
          {activeCategory?.label ?? "Fragrance, adornment, and wardrobe pieces selected to earn their place in your everyday."}
        </p>
      </section>

      <div className="sticky top-[72px] z-30 border-b border-[#dedbd2] bg-[#f8f6f0]/95 backdrop-blur-md lg:top-[82px]">
        <div className="no-scrollbar mx-auto flex max-w-[1440px] items-center gap-6 overflow-x-auto px-5 py-4 sm:px-10 lg:px-14">
          <Link href={query ? `/shop?q=${encodeURIComponent(query)}` : "/shop"} className={`shrink-0 text-[10px] font-semibold uppercase tracking-[0.17em] ${!category ? "text-[#9a7540]" : "text-[#696b66] hover:text-[#1f2922]"}`}>All</Link>
          {categories.map((item) => (
            <Link
              key={item.slug}
              href={`/shop?category=${item.slug}${query ? `&q=${encodeURIComponent(query)}` : ""}`}
              className={`shrink-0 text-[10px] font-semibold uppercase tracking-[0.17em] ${category === item.slug ? "text-[#9a7540]" : "text-[#696b66] hover:text-[#1f2922]"}`}
            >
              {item.name}
            </Link>
          ))}
        </div>
      </div>

      <section className="mx-auto max-w-[1440px] px-5 py-10 sm:px-10 lg:px-14 lg:py-14">
        <div className="mb-9 flex flex-col gap-5 border-b border-[#dedbd2] pb-6 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm text-[#62645f]">{filtered.length} {filtered.length === 1 ? "piece" : "pieces"}</p>
            {query && <Link href={category ? `/shop?category=${category}` : "/shop"} className="mt-2 inline-block text-xs underline underline-offset-4">Clear search</Link>}
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <form action="/shop" className="flex h-11 items-center border border-[#d4cfc5] bg-[#fffefa] px-3">
              {category && <input type="hidden" name="category" value={category} />}
              <Search size={15} className="text-[#79766f]" />
              <input name="q" defaultValue={params.q} placeholder="Search products" className="w-40 bg-transparent px-3 text-xs outline-none sm:w-52" />
            </form>
            <form action="/shop" className="relative">
              {category && <input type="hidden" name="category" value={category} />}
              {query && <input type="hidden" name="q" value={query} />}
              <label htmlFor="sort" className="sr-only">Sort products</label>
              <SlidersHorizontal size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#79766f]" />
              <select id="sort" name="sort" defaultValue={sort} className="h-11 appearance-none border border-[#d4cfc5] bg-[#fffefa] pl-9 pr-9 text-xs outline-none">
                <option value="featured">Featured</option>
                <option value="rating">Top rated</option>
                <option value="price-low">Price: low to high</option>
                <option value="price-high">Price: high to low</option>
              </select>
              <ChevronDown size={14} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2" />
              <button type="submit" className="ml-2 h-11 border border-[#1f2922] px-4 text-[10px] font-semibold uppercase tracking-widest hover:bg-[#1f2922] hover:text-white">Apply</button>
            </form>
          </div>
        </div>

        {filtered.length > 0 ? (
          <div className="grid grid-cols-2 gap-x-4 gap-y-11 md:grid-cols-3 md:gap-x-6 lg:grid-cols-4 lg:gap-x-8 lg:gap-y-14">
            {filtered.map((product, index) => <ProductCard key={product.id} product={product} priority={index < 4} />)}
          </div>
        ) : (
          <div className="py-28 text-center">
            <p className="font-serif text-4xl">Nothing found, just yet.</p>
            <p className="mt-3 text-sm text-[#77736b]">Try a broader phrase or return to the complete collection.</p>
            <Link href="/shop" className="button-dark mt-8">View all pieces</Link>
          </div>
        )}
      </section>
    </main>
  );
}

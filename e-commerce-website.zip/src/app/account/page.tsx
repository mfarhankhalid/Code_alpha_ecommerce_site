import type { Metadata } from "next";
import { Box, ChevronRight, MapPin, PackageCheck, UserRound } from "lucide-react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { formatDate, formatPrice } from "@/lib/format";
import { desc, eq, inArray } from "drizzle-orm";

export const metadata: Metadata = { title: "My Account" };
export const dynamic = "force-dynamic";

export default async function AccountPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/account");

  const userOrders = await db.select().from(orders).where(eq(orders.userId, user.id)).orderBy(desc(orders.createdAt));
  const items = userOrders.length
    ? await db.select().from(orderItems).where(inArray(orderItems.orderId, userOrders.map((order) => order.id)))
    : [];

  return (
    <main className="min-h-[70vh]">
      <section className="bg-[#e9e2d7] px-6 py-14 sm:py-18">
        <div className="mx-auto max-w-[1250px]">
          <p className="eyebrow text-[#9a7540]">The private room</p>
          <h1 className="mt-3 font-serif text-5xl tracking-[-0.04em] sm:text-6xl">Good to see you, {user.name.split(" ")[0]}.</h1>
        </div>
      </section>

      <div className="mx-auto grid max-w-[1250px] gap-12 px-6 py-14 sm:px-10 lg:grid-cols-[260px_1fr] lg:px-6 lg:py-20">
        <aside>
          <div className="border border-[#d9d4ca] bg-[#f1ede5] p-6">
            <span className="grid size-11 place-items-center rounded-full bg-[#1f2922] text-white"><UserRound size={19} /></span>
            <p className="mt-4 font-serif text-xl">{user.name}</p>
            <p className="mt-1 break-all text-xs text-[#77736b]">{user.email}</p>
            <div className="my-5 border-t border-[#d7d2c8]" />
            <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-[#9a7540]">Account</p>
            <p className="mt-3 flex items-center justify-between text-sm">Order history <ChevronRight size={14} /></p>
          </div>
          <Link href="/shop" className="mt-5 flex items-center justify-between border-b border-[#d8d3ca] py-3 text-xs uppercase tracking-[0.13em]">Back to shop <ChevronRight size={14} /></Link>
        </aside>

        <section>
          <div className="flex items-end justify-between border-b border-[#dedbd2] pb-5">
            <div><p className="eyebrow text-[#9a7540]">Purchase history</p><h2 className="mt-2 font-serif text-4xl">Your orders</h2></div>
            <p className="text-xs text-[#77736b]">{userOrders.length} total</p>
          </div>

          {userOrders.length === 0 ? (
            <div className="border-b border-[#dedbd2] py-20 text-center">
              <Box size={34} strokeWidth={1.2} className="mx-auto text-[#9a7540]" />
              <p className="mt-5 font-serif text-3xl">No orders yet</p>
              <p className="mt-3 text-sm text-[#77736b]">When you find your first piece, its story will continue here.</p>
              <Link href="/shop" className="button-dark mt-7">Discover the collection</Link>
            </div>
          ) : (
            <div className="space-y-7 pt-7">
              {userOrders.map((order) => {
                const orderProducts = items.filter((item) => item.orderId === order.id);
                return (
                  <article key={order.id} className="border border-[#d8d3c9] bg-[#fffefa]">
                    <div className="grid gap-4 border-b border-[#e0dcd3] bg-[#f1ede5] px-5 py-4 text-xs sm:grid-cols-[1fr_1fr_1fr_auto] sm:px-7">
                      <div><p className="text-[9px] uppercase tracking-[0.14em] text-[#88837a]">Order</p><p className="mt-1 font-medium">{order.orderNumber}</p></div>
                      <div><p className="text-[9px] uppercase tracking-[0.14em] text-[#88837a]">Placed</p><p className="mt-1">{formatDate(order.createdAt)}</p></div>
                      <div><p className="text-[9px] uppercase tracking-[0.14em] text-[#88837a]">Total</p><p className="mt-1">{formatPrice(order.totalCents)}</p></div>
                      <span className="self-center justify-self-start bg-[#dce6dc] px-3 py-1.5 text-[9px] font-semibold uppercase tracking-[0.14em] text-[#34523c] sm:justify-self-end">{order.status}</span>
                    </div>
                    <div className="space-y-5 p-5 sm:p-7">
                      {orderProducts.map((item) => (
                        <div key={item.id} className="grid grid-cols-[70px_1fr_auto] gap-4">
                          <Link href="/shop" className="aspect-[4/5] overflow-hidden bg-[#ebe6dc]"><img src={item.productImage} alt={item.productName} className="h-full w-full object-cover" /></Link>
                          <div><p className="font-serif text-lg">{item.productName}</p><p className="mt-1 text-[11px] text-[#77736b]">{[item.selectedColor, item.selectedSize].filter(Boolean).join(" · ") || "Standard"} · Qty {item.quantity}</p></div>
                          <p className="text-xs">{formatPrice(item.unitPriceCents * item.quantity)}</p>
                        </div>
                      ))}
                    </div>
                    <div className="grid gap-4 border-t border-[#e0dcd3] px-5 py-5 text-xs text-[#62655f] sm:grid-cols-2 sm:px-7">
                      <p className="flex gap-2"><MapPin size={16} strokeWidth={1.4} /> {order.address}, {order.city} {order.postalCode}</p>
                      <p className="flex gap-2 sm:justify-end"><PackageCheck size={16} strokeWidth={1.4} /> {order.paymentMethod === "demo_card" ? "Demo card" : "Cash on delivery"}</p>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}

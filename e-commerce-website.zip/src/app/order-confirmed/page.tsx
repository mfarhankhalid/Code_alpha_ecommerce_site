import type { Metadata } from "next";
import { Check, PackageCheck } from "lucide-react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { formatPrice } from "@/lib/format";
import { and, eq } from "drizzle-orm";

export const metadata: Metadata = { title: "Order Confirmed" };
export const dynamic = "force-dynamic";

type ConfirmationParams = Promise<{ order?: string }>;

export default async function OrderConfirmedPage({ searchParams }: { searchParams: ConfirmationParams }) {
  const user = await getCurrentUser();
  const { order: orderNumber } = await searchParams;
  if (!user || !orderNumber) redirect("/account");

  const [order] = await db.select().from(orders).where(and(eq(orders.userId, user.id), eq(orders.orderNumber, orderNumber))).limit(1);
  if (!order) redirect("/account");

  return (
    <main className="grid min-h-[72vh] place-items-center bg-[#eee9df] px-6 py-20 text-center">
      <div className="w-full max-w-2xl border border-[#d4cec3] bg-[#f8f6f0] px-7 py-14 shadow-[0_24px_80px_rgba(48,44,36,0.08)] sm:px-14">
        <span className="mx-auto grid size-16 place-items-center rounded-full bg-[#1f2922] text-white"><Check size={27} /></span>
        <p className="eyebrow mt-8 text-[#9a7540]">Order confirmed</p>
        <h1 className="mt-3 font-serif text-5xl tracking-[-0.04em]">Thank you, {user.name.split(" ")[0]}.</h1>
        <p className="mx-auto mt-5 max-w-md text-sm leading-7 text-[#686b65]">Your order has been safely saved. We’ll prepare each piece with care and update its status in your account.</p>
        <div className="mx-auto mt-8 grid max-w-md grid-cols-2 border-y border-[#dedbd2] py-5 text-left">
          <div><p className="text-[9px] uppercase tracking-[0.16em] text-[#89847b]">Order number</p><p className="mt-2 text-sm font-medium">{order.orderNumber}</p></div>
          <div className="border-l border-[#dedbd2] pl-6"><p className="text-[9px] uppercase tracking-[0.16em] text-[#89847b]">Total</p><p className="mt-2 text-sm font-medium">{formatPrice(order.totalCents)}</p></div>
        </div>
        <div className="mt-7 flex items-center justify-center gap-2 text-xs text-[#686b65]"><PackageCheck size={18} /> Status: Confirmed</div>
        <div className="mt-9 flex flex-col justify-center gap-3 sm:flex-row"><Link href="/account" className="button-dark">View my orders</Link><Link href="/shop" className="button-outline">Continue shopping</Link></div>
      </div>
    </main>
  );
}

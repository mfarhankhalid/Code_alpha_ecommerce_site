import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/auth-form";
import { getCurrentUser } from "@/lib/auth";

export const metadata: Metadata = { title: "Create an Account" };

type RegisterParams = Promise<{ next?: string }>;

export default async function RegisterPage({ searchParams }: { searchParams: RegisterParams }) {
  const user = await getCurrentUser();
  const { next } = await searchParams;
  const nextPath = next?.startsWith("/") ? next : "/account";
  if (user) redirect(nextPath);

  return (
    <main className="grid min-h-[760px] lg:grid-cols-2">
      <div className="relative hidden overflow-hidden lg:block">
        <img src="https://images.pexels.com/photos/5119928/pexels-photo-5119928.jpeg?auto=compress&cs=tinysrgb&w=1200" alt="Models in timeless outerwear" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-[#1f2922]/20" />
        <div className="absolute bottom-14 left-14 max-w-md text-white">
          <p className="eyebrow text-white/70">Join the story</p>
          <p className="mt-4 font-serif text-4xl leading-tight">Thoughtful pieces, considered slowly.</p>
        </div>
      </div>
      <div className="flex items-center justify-center px-6 py-20 sm:px-12">
        <div className="w-full max-w-md">
          <p className="eyebrow text-[#9a7540]">Your account</p>
          <h1 className="mt-3 font-serif text-5xl tracking-[-0.035em]">Become part of Aurélia</h1>
          <p className="mt-4 text-sm leading-6 text-[#77736b]">Create an account to check out securely and keep every order close at hand.</p>
          <AuthForm mode="register" nextPath={nextPath} />
          <p className="mt-6 text-center text-[11px] leading-5 text-[#929087]">By creating an account, you agree to our terms and privacy policy.</p>
        </div>
      </div>
    </main>
  );
}

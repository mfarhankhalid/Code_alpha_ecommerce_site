import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/auth-form";
import { getCurrentUser } from "@/lib/auth";

export const metadata: Metadata = { title: "Sign In" };

type LoginParams = Promise<{ next?: string }>;

export default async function LoginPage({ searchParams }: { searchParams: LoginParams }) {
  const user = await getCurrentUser();
  const { next } = await searchParams;
  const nextPath = next?.startsWith("/") ? next : "/account";
  if (user) redirect(nextPath);

  return (
    <main className="grid min-h-[740px] lg:grid-cols-2">
      <div className="flex items-center justify-center px-6 py-20 sm:px-12">
        <div className="w-full max-w-md">
          <p className="eyebrow text-[#9a7540]">Welcome back</p>
          <h1 className="mt-3 font-serif text-5xl tracking-[-0.035em]">Sign in to Aurélia</h1>
          <p className="mt-4 text-sm leading-6 text-[#77736b]">View your orders, save your details, and move through checkout a little faster.</p>
          <AuthForm mode="login" nextPath={nextPath} />
        </div>
      </div>
      <div className="relative hidden overflow-hidden lg:block">
        <img src="https://images.pexels.com/photos/8217775/pexels-photo-8217775.jpeg?auto=compress&cs=tinysrgb&w=1200" alt="Aurélia fragrance campaign" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-[#1f2922]/20" />
        <div className="absolute bottom-14 left-14 max-w-md text-white">
          <p className="eyebrow text-white/70">The private room</p>
          <p className="mt-4 font-serif text-4xl leading-tight">Your collection, your orders, all in one quiet place.</p>
        </div>
      </div>
    </main>
  );
}

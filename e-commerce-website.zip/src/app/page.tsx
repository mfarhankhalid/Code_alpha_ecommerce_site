import { ArrowRight, Gem, PackageCheck, RefreshCcw, ShieldCheck, Sparkles, Star } from "lucide-react";
import Link from "next/link";
import { ProductCard } from "@/components/product-card";
import { categories, getProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const products = await getProducts();
  const featured = products.filter((product) => product.featured).slice(0, 4);
  const newArrivals = products.slice(4, 8);

  return (
    <main>
      <section className="grid min-h-[660px] overflow-hidden bg-[#e8e0d3] lg:grid-cols-[46%_54%]">
        <div className="relative z-10 flex items-center px-7 py-20 sm:px-12 lg:px-[10%] lg:py-24">
          <div className="max-w-xl animate-rise">
            <p className="eyebrow mb-7 flex items-center gap-3 text-[#806a49]">
              <span className="h-px w-8 bg-[#a88c61]" /> The art of the everyday
            </p>
            <h1 className="font-serif text-[clamp(3.4rem,7vw,7.1rem)] leading-[0.88] tracking-[-0.045em] text-[#1e2821]">
              Leave a quiet<br /><em className="font-normal text-[#8d7048]">impression.</em>
            </h1>
            <p className="mt-8 max-w-md text-[15px] leading-7 text-[#5e615b] sm:text-base">
              Fragrance, adornment, and wardrobe pieces chosen for how they make ordinary moments feel.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link href="/shop" className="button-dark">Explore the collection <ArrowRight size={15} /></Link>
              <Link href="/shop?category=fragrance" className="button-outline">Discover fragrance</Link>
            </div>
          </div>
          <span className="absolute bottom-8 left-8 hidden font-serif text-[10rem] leading-none text-[#dbd0bf]/55 lg:block">A</span>
        </div>
        <div className="relative min-h-[520px] lg:min-h-[660px]">
          <img
            src="https://images.pexels.com/photos/8217788/pexels-photo-8217788.jpeg?auto=compress&cs=tinysrgb&w=1500"
            alt="Woman holding a fragrance bottle in warm studio light"
            className="absolute inset-0 h-full w-full object-cover object-center"
          />
          <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between border border-white/35 bg-[#212821]/85 p-5 text-white backdrop-blur-sm sm:bottom-9 sm:left-9 sm:right-auto sm:w-[340px]">
            <div>
              <p className="text-[9px] uppercase tracking-[0.2em] text-white/55">Scent of the month</p>
              <p className="mt-1 font-serif text-2xl">Ambre Noir</p>
              <p className="mt-1 text-xs text-white/65">Amber · Vanilla · Sandalwood</p>
            </div>
            <Link href="/product/ambre-noir-eau-de-parfum" aria-label="Shop Ambre Noir" className="grid size-10 place-items-center rounded-full border border-white/40 hover:bg-white hover:text-[#1f2922]">
              <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      <section className="border-b border-[#dedbd2] bg-[#f8f6f0] py-10">
        <div className="no-scrollbar mx-auto flex max-w-[1440px] items-center gap-3 overflow-x-auto px-6 sm:px-10 lg:justify-center lg:px-14">
          <span className="mr-4 shrink-0 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#837e75]">Shop by ritual</span>
          {categories.map((category) => (
            <Link key={category.slug} href={`/shop?category=${category.slug}`} className="shrink-0 rounded-full border border-[#cec9bf] px-5 py-2.5 text-xs hover:border-[#1f2922] hover:bg-[#1f2922] hover:text-white">
              {category.name}
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-[1440px] px-5 py-20 sm:px-10 lg:px-14 lg:py-28">
        <div className="mb-10 flex items-end justify-between gap-6 lg:mb-14">
          <div>
            <p className="eyebrow text-[#9a7540]">The considered edit</p>
            <h2 className="mt-3 font-serif text-4xl tracking-[-0.025em] sm:text-5xl">Objects worth keeping</h2>
          </div>
          <Link href="/shop" className="hidden items-center gap-2 border-b border-[#1f2922] pb-1 text-xs uppercase tracking-[0.15em] sm:flex">Shop all <ArrowRight size={14} /></Link>
        </div>
        <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4 md:gap-x-6 lg:gap-x-8">
          {featured.map((product, index) => <ProductCard key={product.id} product={product} priority={index < 2} />)}
        </div>
        <Link href="/shop" className="button-outline mt-12 w-full sm:hidden">Shop all</Link>
      </section>

      <section className="bg-[#d9cfc0] px-5 py-20 sm:px-10 lg:px-14 lg:py-28">
        <div className="mx-auto grid max-w-[1330px] overflow-hidden bg-[#1f2922] text-white lg:grid-cols-2">
          <div className="relative min-h-[540px] lg:min-h-[680px]">
            <img src="https://images.pexels.com/photos/30405427/pexels-photo-30405427.jpeg?auto=compress&cs=tinysrgb&w=1200" alt="Fragrance bottles displayed with flowers and books" className="absolute inset-0 h-full w-full object-cover" />
            <p className="absolute left-6 top-6 bg-[#f8f6f0] px-4 py-2 text-[9px] font-semibold uppercase tracking-[0.2em] text-[#1f2922]">The fragrance room</p>
          </div>
          <div className="flex items-center px-8 py-16 sm:px-16 lg:px-[13%]">
            <div>
              <Sparkles size={25} strokeWidth={1.2} className="text-[#c7a86f]" />
              <p className="eyebrow mt-8 text-[#c7a86f]">Made to unfold slowly</p>
              <h2 className="mt-4 max-w-lg font-serif text-[clamp(2.8rem,5vw,5.4rem)] leading-[0.95] tracking-[-0.035em]">A scent is a place you can carry.</h2>
              <p className="mt-7 max-w-md text-sm leading-7 text-white/60">Our fragrances are composed in small batches with expressive natural extracts and an instinct for restraint. Designed for skin, not rooms.</p>
              <Link href="/shop?category=fragrance" className="button-light mt-9">Find your signature <ArrowRight size={15} /></Link>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[1440px] px-5 py-20 sm:px-10 lg:px-14 lg:py-28">
        <div className="mb-10 text-center lg:mb-14">
          <p className="eyebrow text-[#9a7540]">Recently arrived</p>
          <h2 className="mt-3 font-serif text-4xl tracking-[-0.025em] sm:text-5xl">New stories, just in</h2>
        </div>
        <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4 md:gap-x-6 lg:gap-x-8">
          {newArrivals.map((product) => <ProductCard key={product.id} product={product} />)}
        </div>
      </section>

      <section className="border-y border-[#d9d5cb] bg-[#f0ece4]">
        <div className="mx-auto grid max-w-[1440px] grid-cols-2 md:grid-cols-5">
          {categories.map((category) => (
            <Link key={category.slug} href={`/shop?category=${category.slug}`} className="group relative aspect-[3/4] overflow-hidden border-r border-[#f0ece4] last:border-r-0">
              <img src={category.image} alt={category.name} className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-black/15 transition group-hover:bg-black/25" />
              <div className="absolute inset-x-0 bottom-0 p-5 text-white sm:p-7">
                <p className="font-serif text-2xl sm:text-3xl">{category.name}</p>
                <p className="mt-1 hidden text-[9px] uppercase tracking-[0.18em] text-white/75 sm:block">{category.label}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-6 py-24 text-center sm:py-32">
        <Gem size={25} strokeWidth={1.2} className="mx-auto text-[#9a7540]" />
        <blockquote className="mt-8 font-serif text-[clamp(2rem,4.5vw,4rem)] leading-[1.08] tracking-[-0.025em] text-[#283129]">
          “True luxury is not about having more. It is about choosing better.”
        </blockquote>
        <div className="mt-7 flex items-center justify-center gap-1 text-[#a67c45]">
          {[1, 2, 3, 4, 5].map((star) => <Star key={star} size={13} fill="currentColor" />)}
        </div>
        <p className="mt-3 text-[10px] uppercase tracking-[0.2em] text-[#77736b]">4.9 from our community</p>
      </section>

      <section className="border-t border-[#dedbd2]">
        <div className="mx-auto grid max-w-[1440px] divide-y divide-[#dedbd2] px-6 sm:grid-cols-3 sm:divide-x sm:divide-y-0 sm:px-10 lg:px-14">
          <div className="flex items-start gap-4 py-8 sm:px-7"><PackageCheck size={22} strokeWidth={1.3} /><div><p className="text-xs font-semibold uppercase tracking-[0.14em]">Complimentary delivery</p><p className="mt-1 text-xs text-[#77736b]">On all orders over $150</p></div></div>
          <div className="flex items-start gap-4 py-8 sm:px-7"><RefreshCcw size={21} strokeWidth={1.3} /><div><p className="text-xs font-semibold uppercase tracking-[0.14em]">Considered returns</p><p className="mt-1 text-xs text-[#77736b]">14 days to decide at home</p></div></div>
          <div className="flex items-start gap-4 py-8 sm:px-7"><ShieldCheck size={22} strokeWidth={1.3} /><div><p className="text-xs font-semibold uppercase tracking-[0.14em]">Secure checkout</p><p className="mt-1 text-xs text-[#77736b]">Your information stays protected</p></div></div>
        </div>
      </section>
    </main>
  );
}

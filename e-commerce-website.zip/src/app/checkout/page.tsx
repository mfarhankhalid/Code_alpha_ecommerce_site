import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { CheckoutView } from "@/components/checkout-view";
import { getCurrentUser } from "@/lib/auth";

export const metadata: Metadata = { title: "Secure Checkout" };

export default async function CheckoutPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/checkout");
  return <CheckoutView user={{ name: user.name, email: user.email }} />;
}

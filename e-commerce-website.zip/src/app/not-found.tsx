import { ArrowLeft } from "lucide-react";
import Link from "next/link";

export default function NotFound() {
  return (
    <main className="grid min-h-[68vh] place-items-center bg-[#eee8de] px-6 py-24 text-center">
      <div>
        <p className="font-serif text-8xl text-[#b59668]">404</p>
        <h1 className="mt-4 font-serif text-4xl sm:text-5xl">This piece has moved on.</h1>
        <p className="mx-auto mt-4 max-w-md text-sm leading-6 text-[#6f706a]">The page you followed is no longer here, but there is plenty more to discover.</p>
        <Link href="/shop" className="button-dark mt-8"><ArrowLeft size={15} /> Return to the collection</Link>
      </div>
    </main>
  );
}

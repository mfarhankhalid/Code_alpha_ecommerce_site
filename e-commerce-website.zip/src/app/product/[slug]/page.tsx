import type { Metadata } from "next";
import { ChevronRight, PackageCheck, ShieldCheck, Star } from "lucide-react";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ProductPurchase } from "@/components/add-to-cart";
import { ProductCard } from "@/components/product-card";
import { getProductBySlug, getProducts } from "@/lib/catalog";
import { formatPrice } from "@/lib/format";

export const dynamic = "force-dynamic";

type ProductParams = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: ProductParams }): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return { title: "Piece not found" };
  return { title: product.name, description: product.description, openGraph: { images: [product.image] } };
}

export default async function ProductPage({ params }: { params: ProductParams }) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const allProducts = await getProducts();
  const related = allProducts.filter((item) => item.category === product.category && item.id !== product.id).slice(0, 4);
  if (related.length < 4) {
    related.push(...allProducts.filter((item) => item.category !== product.category).slice(0, 4 - related.length));
  }

  const cartProduct = {
    id: product.id,
    slug: product.slug,
    name: product.name,
    tagline: product.tagline,
    image: product.image,
    imageAlt: product.imageAlt,
    priceCents: product.priceCents,
    stock: product.stock,
  };

  return (
    <main>
      <div className="mx-auto flex max-w-[1440px] items-center gap-2 px-5 py-5 text-[10px] uppercase tracking-[0.14em] text-[#77736b] sm:px-10 lg:px-14">
        <Link href="/" className="hover:text-[#1f2922]">Home</Link><ChevronRight size={11} />
        <Link href={`/shop?category=${product.category}`} className="capitalize hover:text-[#1f2922]">{product.category}</Link><ChevronRight size={11} />
        <span className="truncate text-[#1f2922]">{product.name}</span>
      </div>

      <section className="mx-auto grid max-w-[1440px] gap-9 px-5 pb-20 sm:px-10 lg:grid-cols-[minmax(0,1.35fr)_minmax(380px,0.65fr)] lg:gap-16 lg:px-14 lg:pb-28">
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="product-image-wrap aspect-[4/5] sm:col-span-2 sm:aspect-[5/4]">
            <img src={product.image} alt={product.imageAlt} className="h-full w-full object-cover" />
            {product.badge && <span className="absolute left-5 top-5 bg-[#f8f6f0] px-4 py-2 text-[9px] font-semibold uppercase tracking-[0.16em]">{product.badge}</span>}
          </div>
          <div className="product-image-wrap hidden aspect-square sm:block">
            <img src={product.image} alt={`${product.name} detail`} className="h-full w-full scale-125 object-cover object-left" />
          </div>
          <div className="hidden aspect-square items-center justify-center bg-[#e6dfd2] p-12 text-center sm:flex">
            <div>
              <span className="font-serif text-6xl text-[#9c7b4e]">“</span>
              <p className="font-serif text-2xl leading-tight text-[#293229]">Made to become part of your story, not just your wardrobe.</p>
            </div>
          </div>
        </div>

        <div className="lg:pt-6">
          <div className="lg:sticky lg:top-32">
            <p className="eyebrow capitalize text-[#9a7540]">{product.category}</p>
            <h1 className="mt-3 font-serif text-[clamp(2.8rem,5vw,4.8rem)] leading-[0.95] tracking-[-0.04em]">{product.name}</h1>
            <p className="mt-3 text-sm text-[#77736b]">{product.tagline}</p>
            <div className="mt-5 flex items-center justify-between border-b border-[#ddd8ce] pb-6">
              <div className="text-lg">
                <span>{formatPrice(product.priceCents)}</span>
                {product.compareAtCents && <span className="ml-3 text-sm text-[#9b968c] line-through">{formatPrice(product.compareAtCents)}</span>}
              </div>
              <div className="flex items-center gap-1 text-[#a67c45]"><Star size={13} fill="currentColor" /><span className="text-xs text-[#575a55]">{(product.rating / 10).toFixed(1)} · {product.reviewCount} reviews</span></div>
            </div>
            <p className="mt-6 text-sm leading-7 text-[#595e58]">{product.description}</p>

            <ProductPurchase product={cartProduct} colors={product.colors} sizes={product.sizes} />

            <div className="mt-7 divide-y divide-[#ddd8ce] border-y border-[#ddd8ce]">
              <details className="group py-4" open>
                <summary className="flex cursor-pointer list-none items-center justify-between text-xs font-semibold uppercase tracking-[0.14em]">Materials & details <span className="text-lg font-light group-open:rotate-45">+</span></summary>
                <p className="mt-3 pr-6 text-xs leading-6 text-[#77736b]">Selected for quality, finish, and longevity. Each piece is inspected by hand before dispatch and arrives in recyclable signature packaging.</p>
              </details>
              <details className="group py-4">
                <summary className="flex cursor-pointer list-none items-center justify-between text-xs font-semibold uppercase tracking-[0.14em]">Care guide <span className="text-lg font-light group-open:rotate-45">+</span></summary>
                <p className="mt-3 pr-6 text-xs leading-6 text-[#77736b]">Store in a cool, dry place away from direct sunlight. Treat gently and keep in the provided dust bag or box between uses.</p>
              </details>
            </div>

            <div className="mt-6 grid gap-4 text-xs text-[#60645f] sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
              <div className="flex gap-3"><PackageCheck size={19} strokeWidth={1.4} /><p><strong className="block font-medium text-[#1f2922]">Delivery included over $150</strong>Dispatched in 1–2 working days</p></div>
              <div className="flex gap-3"><ShieldCheck size={19} strokeWidth={1.4} /><p><strong className="block font-medium text-[#1f2922]">Buy with confidence</strong>Secure checkout · 14-day returns</p></div>
            </div>
          </div>
        </div>
      </section>

      <section className="border-t border-[#dedbd2] bg-[#f1ede5] px-5 py-20 sm:px-10 lg:px-14 lg:py-24">
        <div className="mx-auto max-w-[1330px]">
          <div className="mb-10 flex items-end justify-between">
            <div><p className="eyebrow text-[#9a7540]">Complete the story</p><h2 className="mt-3 font-serif text-4xl">You may also like</h2></div>
            <Link href={`/shop?category=${product.category}`} className="hidden border-b border-[#1f2922] pb-1 text-[10px] uppercase tracking-[0.15em] sm:block">View category</Link>
          </div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4 md:gap-x-7">
            {related.map((item) => <ProductCard key={item.id} product={item} />)}
          </div>
        </div>
      </section>
    </main>
  );
}
